<?php
session_start();
?>
<html>
	<head>
		<title>The Marshall Company Accessories</title>
		<link rel="stylesheet" type="text/CSS" href="src/CSS/style.css">
	</head>
	<body>
		<?php
			require_once 'header.php';
		?>
		<p> Accessories options here once my dad gets them to me
		<?php	
			require_once 'footer.php';
		?>
	</body>
</html>